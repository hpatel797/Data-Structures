/*
 * Bag.cpp
 *
 *  Created on: Mar 21, 2018
 *      Author: hpatel797
 */
#include <iostream>
#include "Bag.h"
using namespace Patel_Harsh;

// This class will create a bag of a given amount of integers and the functions will
//remove, insert, or search for a value.

Bag::Bag(){
	USED = 0; //constructor
}
void Bag::insert(int value){
	if (USED < 20){
		data[USED] = value;  // add number
		++USED;
	}
}
int Bag::search(int value){
	bool found = false;
	int found_pos = -1;
	for (int i = 0; i<USED && !found; ++i){
		if (data[i] == value){
			found = true;
			found_pos = i; // save location
		}
	}
	if (found) return found_pos; //if it was found, return position
	else return -1; // return negative number to produce error message to user
}

void Bag::remove(int value){
	int i=0, found_pos = -1;
	while(data[i] != value) ++i; //locate the value
	found_pos = i;
	for (i = found_pos;i<USED; ++i){
		data[i] = data[i+1]; //shift everything to left (data[8] has value of data[9], etc...
	}
	--USED;
}



