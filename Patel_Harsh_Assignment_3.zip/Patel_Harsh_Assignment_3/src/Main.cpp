//============================================================================
// Name        : Patel_Harsh_Assignment_3.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Bag.h"
using namespace Patel_Harsh;
using namespace std;

int main() {
	srand(time(0)); // get a new bag each time you run
	while (true){
		Bag b;
		//bag_type value;
		cout << "The bag capacity is: " <<b.capacity() << endl;
		cout << "How many elements do you want to insert? (Max 20): ";
		int add_vals; cin >> add_vals;
		for ( int i = 0; i < add_vals; ++i)
			b.insert(rand() % 20 + 1);
		cout << " \nCurrently, the bag includes: ";
		for (int i = 0; i < b.size(); ++i) cout << b.val(i) << " ";
		cout << "\n The bag size is " << b.size() << endl;
		while (true){
			cout << "\nWhich number do you want to remove? (Insert number not the index): ";
			int rmv; cin >> rmv;
			b.remove(rmv);
			cout << "\n The bag now includes: ";
			for (int i = 0; i < b.size(); ++i) cout << b.val(i) << " ";
			cout << "\n The bag size is now " << b.size() << endl;
			cout << "Do you want to remove any more numbers? (yes or no only): ";
			string input; cin >> input;
			if (input == "no") break;
		}
		while (true){
			cout << "\nEnter the number for which you want the index of: ";
			int numsearch; cin >> numsearch;
			if (b.search(numsearch) < 0)
				cout << "\nSorry, that number is not in the bag" << endl;
			else cout << "\n The number " << numsearch << " is located in index " << b.search(numsearch)
				<< " in the bag. " << endl;
			cout << "Do you want to search any more numbers? (yes or no only): ";
			string input; cin >> input;
			if (input == "no") break;
		}
		cout << "Would you like to start over with a new bag? (yes or no only): ";
		string input; cin >> input;
		if (input == "no") break;
	}
	return 0;

}
