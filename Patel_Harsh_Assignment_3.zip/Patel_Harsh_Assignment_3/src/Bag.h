/*
 * Patel_Harsh_Assignment_3.h
 *
 *  Created on: Mar 21, 2018
 *      Author: hpatel797
 */

#ifndef BAG_H_
#define BAG_H_

namespace Patel_Harsh{
	typedef int bag_type;
	class Bag{
		public:
			Bag();
			static const size_t CAPACITY = 20;
			size_t capacity() const {return CAPACITY;}
			size_t size() const {return USED;}
			void insert (int value);
			void remove (int value);
			int search(int value); // searching
			int val(int index) const { return data[index]; } // to display contents of bag
		private:
			int data[20];
			size_t USED;

	};
}
#endif /* BAG_H_ */
