//using namespace std;
#include "BinarySearch.h"
#include <cstddef>


BinarySearch::BinarySearch(){}


BinarySearch::~BinarySearch(){}

int BinarySearch::binary_search(int* arr, int length, int value) {

	if (arr == nullptr || length < 0) return -1;
	int left = 0;
	int right = length - 1;
	int mid;
	while (left <= right)
	{
		mid = left + (right - left) / 2;
		if (arr[mid] == value) {
			return mid;
		}
		else if (arr[mid < value])
		{
			left = mid + 1;
		}
		else if (arr[mid] > value)
		{
			right = mid - 1;
		}
	} return -1;
}


