#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

#pragma once
#include "LinkedListEntry.h"
template <class T>
class LinkedLIst
{
	float threshold;

	int maxSize;

	int BUCKET;

	int size;

	LinkedLIstEntry<T> **table;
public:
	LinkedLIst();
	~LinkedLIst();
	void resize();
	void setThreshold(float);
	T get(int);
	void put(int, T);
	void remove(int);
	void setBucket(int);


};






#endif /* LINKEDLIST_H_ */
