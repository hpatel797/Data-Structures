#ifndef LINKEDLISTENTRY_H_
#define LINKEDLISTENTRY_H_

#pragma once
template <class T>
class LinkedLIstEntry
{
private:

	int key;

	T value;

	LinkedLIstEntry *next;
public:
	LinkedLIstEntry(int,T);
	~LinkedLIstEntry();
	int getKey();
	T getValue();
	void setValue(T);
	LinkedLIstEntry *getNext();
	void setNext(LinkedLIstEntry *);



};





#endif /* LINKEDLISTENTRY_H_ */
