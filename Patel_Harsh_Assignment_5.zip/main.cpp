/*For linkedliists, insertion and deletion from any point of a linked list is O(1).
Inserting and deleting a range of elements is also O(1). Transversing, however is
O(N) and random access in a linked list is not possible unless you traverse in order
to find the N'th element.

For binary search trees, insertion and deletion are both O(log n). Searching for
an element is also O(log n). There isnt any range insertion or deletion in trees.
Random access, like in linked lists, is also not possible, unless you go through
each root/leaf to find the value.

The advantage of replacing linkedlists with binary search tree and vice versa lies
in the functionality. O(log N) is faster than O(n), so if you need to search a lot,
a tree would be more optimal than a linkedlist. If you need to insert/delete a lot
without searching, a linked list would be better. When the size becomes 11, there
are more elements so it wouldn't be efficient to use linked list in case you have to
search. Likewise, when the size becomes 8, its better to use linkedlist since inserting
is only O(1) and there aren't too many elements in case you do have to search over it. */

#include <iostream>
#include "LinkedList.h"
#include "BinarySearch.h"
#include "LinkedList.tpp"
#include "LinkedListEntry.h"
#include "LinkedListEntry.tpp"
using namespace std;
int main() {
	int val,keyData,Data;

	LinkedLIst<int> * linkedlist = new LinkedLIst<int>();
	BinarySearch* binarysearch = new BinarySearch();
	cout << "BUCKET SIZE:";
	cin >> val;
	if (val > 8) {
		cout << "*******************************Hash Search*******************************";
		cout << endl;
		linkedlist->setBucket(val);
		linkedlist->resize();

		for (int i = 0; i < val; i++) {
			cout << "Data:";
			cin >> Data;
			keyData=linkedlist->get(Data);
			keyData = Data % val;
			linkedlist->put(keyData, Data);
		}
		cout << endl;
		for (int i = 0; i < val; i++)
		{
			cout << i;
			cout << " --> " << linkedlist->get(i);
			cout << endl;
		}
	}
	else if (val == 8)
	{
		cout << "****************Binary Search*************************";
		cout << endl;
		int a[8] = { 0 };
		int middle;
		for (int i = 0; i < val; i++) {
			cout << "Data:";
			cin >> a[i];
		}

		for (int i = 0;i < val; i++) {
			int rel= binarysearch->binary_search(a, 8, a[0]);
			a[i]= rel;
		}

		for (int i = 0; i < val; i++)
		{
			cout << i;
			cout << " --> " << a[i];
			cout << endl;
		}
	}
	else
	{
		cout << "**************************Hash Search****************************";
		cout << endl;
		linkedlist->setBucket(val);
		linkedlist->resize();

		for (int i = 0; i < val; i++) {
			cout << "Data:";
			cin >> Data;
			keyData = Data % val;
			linkedlist->put(keyData, Data);
		}
		cout << endl;
		for (int i = 0; i < val; i++)
		{
			cout << i;
			cout << " --> " << linkedlist->get(i);
			cout << endl;
		}

	}

    return 0;
}
