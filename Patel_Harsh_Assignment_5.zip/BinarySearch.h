#ifndef BINARYSEARCH_H_
#define BINARYSEARCH_H_

#pragma once
class BinarySearch
{
public:
	BinarySearch();
	~BinarySearch();
	int binary_search(int*, int, int);
};





#endif /* BINARYSEARCH_H_ */
